# CAN Simulation Placeholder (as Python can't interface with real CAN without hardware)
print("Simulating CAN communication...")
message = {"id": 0x100, "data": [0x11, 0x22, 0x33, 0x44]}
print("Sending message:", message)