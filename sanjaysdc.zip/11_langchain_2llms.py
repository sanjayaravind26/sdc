print("LangChain with two LLMs (simulated)")
response1 = "LLM1: Hello!"
response2 = "LLM2: Hi there!"
print(response1)
print(response2)