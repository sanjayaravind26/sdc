from transformers import pipeline

summarizer = pipeline("summarization")
text = "Machine learning is a branch of artificial intelligence that focuses on building applications that learn from data and improve their accuracy over time without being programmed to do so."
summary = summarizer(text, max_length=30, min_length=10, do_sample=False)
print("Summary:", summary[0]['summary_text'])