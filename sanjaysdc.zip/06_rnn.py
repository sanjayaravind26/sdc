from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense
import numpy as np

X = np.array([[[0.1]], [[0.2]], [[0.3]], [[0.4]]])
y = np.array([[0.2], [0.3], [0.4], [0.5]])

model = Sequential([
    SimpleRNN(10, activation='tanh', input_shape=(1, 1)),
    Dense(1)
])

model.compile(optimizer='adam', loss='mse')
model.fit(X, y, epochs=200, verbose=0)
print("Predicted:", model.predict(np.array([[[0.5]]])))