print("LangChain with one LLM and another tool (simulated)")
llm_response = "LLM: Processing text..."
tool_response = "Tool: Analyzed successfully."
print(llm_response)
print(tool_response)